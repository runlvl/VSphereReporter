"""
VSphere Reporter Web Application Package
"""