#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VMware vSphere Reporter v29.0 - Web-Anwendung
Eine umfassende Berichtsanwendung für VMware vSphere-Umgebungen

Dies ist der Haupteinstiegspunkt für die Webanwendung.
"""

import os
import sys
import logging
import tempfile
from datetime import datetime
from functools import wraps

# Flask und Erweiterungen importieren
from flask import Flask, render_template, redirect, url_for, request, session, flash, send_file, jsonify, abort
from flask_wtf.csrf import CSRFProtect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField
from wtforms.validators import DataRequired

# Lokale Module importieren
import demo_data
from webapp.vsphere_client import VSphereClient
from webapp.report_generator import ReportGenerator
from webapp.utils.error_handler import handle_vsphere_errors, VSphereReporterError
from webapp.utils.logger import setup_logger

# Logger konfigurieren
logger = setup_logger('vsphere_reporter')

# App-Konfiguration
app = Flask(__name__, template_folder='templates', static_folder='static')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'vsphere-reporter-v29-secret-key')
app.config['SESSION_TYPE'] = 'filesystem'
app.config['UPLOAD_FOLDER'] = os.path.join(tempfile.gettempdir(), 'vsphere-reporter-exports')
# Standardmäßig ist der Demo-Modus deaktiviert, außer wenn er explizit aktiviert wurde
app.config['DEMO_MODE'] = os.environ.get('VSPHERE_REPORTER_DEMO', 'False').lower() in ('true', '1', 't')
app.config['JSON_AS_ASCII'] = False  # Stellt sicher, dass JSON-Antworten Unicode-Zeichen korrekt verarbeiten
app.config['JSONIFY_PRETTYPRINT_REGULAR'] = True

# Stelle sicher, dass das Export-Verzeichnis existiert
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# CSRF-Schutz aktivieren
csrf = CSRFProtect(app)

# Login-Formular definieren
class LoginForm(FlaskForm):
    server = StringField('vCenter-Server', validators=[DataRequired()])
    username = StringField('Benutzername', validators=[DataRequired()])
    password = PasswordField('Passwort', validators=[DataRequired()])
    ignore_ssl = BooleanField('SSL-Zertifikatsprüfung überspringen')

# vSphere-Client global verfügbar machen
vsphere_client = None

# Hilfsfunktionen

def login_required(f):
    """
    Decorator, der prüft, ob ein Benutzer angemeldet ist.
    Wenn nicht, wird er zur Anmeldeseite weitergeleitet.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('is_authenticated', False) and not app.config['DEMO_MODE']:
            flash('Bitte melden Sie sich an, um diese Seite aufzurufen.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Routen

@app.route('/')
def index():
    """
    Startseite der Anwendung.
    Zeigt das Dashboard an, wenn der Benutzer angemeldet ist,
    ansonsten die Anmeldeseite.
    """
    if session.get('is_authenticated', False) or app.config['DEMO_MODE']:
        # Statistiken abrufen
        try:
            if app.config['DEMO_MODE']:
                logger.info("Verwende Demo-Daten für Dashboard")
                stats = demo_data.get_dashboard_stats()
                charts = demo_data.get_dashboard_charts()
            else:
                logger.info("Sammle echte Daten vom vCenter für Dashboard")
                # Hier die echten Daten vom vCenter sammeln
                vmware_tools = vsphere_client.get_vmware_tools_status() if vsphere_client else []
                snapshots = vsphere_client.get_snapshots() if vsphere_client else []
                orphaned_vmdks = vsphere_client.get_orphaned_vmdks() if vsphere_client else []
                
                # Stats aus echten Daten erzeugen
                stats = {
                    'vms_total': len(vmware_tools),
                    'snapshots_total': len(snapshots),
                    'orphaned_vmdks_total': len(orphaned_vmdks) if orphaned_vmdks else 0,
                    'outdated_vmware_tools': sum(1 for vm in vmware_tools if vm.get('status') == 'outdated'),
                    'old_snapshots': sum(1 for snap in snapshots if snap.get('age_days', 0) > 30)
                }
                
                # Charts aus echten Daten erzeugen
                tools_versions = {}
                for vm in vmware_tools:
                    version = vm.get('version', 'Unknown')
                    tools_versions[version] = tools_versions.get(version, 0) + 1
                
                charts = {
                    'vmware_tools_versions': [{'name': v, 'value': c} for v, c in tools_versions.items()],
                    'snapshot_age_distribution': [
                        {'name': '< 7 Tage', 'value': sum(1 for s in snapshots if s.get('age_days', 0) < 7)},
                        {'name': '7-30 Tage', 'value': sum(1 for s in snapshots if 7 <= s.get('age_days', 0) <= 30)},
                        {'name': '> 30 Tage', 'value': sum(1 for s in snapshots if s.get('age_days', 0) > 30)}
                    ]
                }
            
            return render_template('dashboard.html', 
                                stats=stats, 
                                charts=charts,
                                demo_mode=app.config['DEMO_MODE'])
        except Exception as e:
            logger.error(f"Fehler beim Laden des Dashboards: {e}")
            flash(f"Fehler beim Laden des Dashboards: {str(e)}", 'danger')
            return render_template('dashboard.html', 
                                stats={}, 
                                charts={},
                                demo_mode=app.config['DEMO_MODE'])
    else:
        return redirect(url_for('login'))

@app.route('/vmware-tools')
@login_required
def vmware_tools():
    """
    Zeigt den Status der VMware Tools für alle VMs an.
    """
    try:
        if app.config['DEMO_MODE']:
            logger.info("Verwende Demo-Daten für VMware Tools")
            vms_with_tools = demo_data.generate_vmware_tools_data(30)
        else:
            logger.info("Sammle echte VMware Tools-Daten vom vCenter")
            # Hier die echten Daten vom vCenter abrufen
            vms_with_tools = vsphere_client.get_vmware_tools_status() if vsphere_client else []
        
        return render_template('vmware_tools.html', 
                            vms_with_tools=vms_with_tools,
                            demo_mode=app.config['DEMO_MODE'])
    except Exception as e:
        logger.error(f"Fehler beim Abrufen der VMware Tools-Daten: {e}")
        flash(f"Fehler beim Abrufen der VMware Tools-Daten: {str(e)}", 'danger')
        return render_template('vmware_tools.html', 
                            vms_with_tools=[],
                            demo_mode=app.config['DEMO_MODE'])

@app.route('/snapshots')
@login_required
def snapshots():
    """
    Zeigt eine Liste aller VM-Snapshots an.
    """
    try:
        if app.config['DEMO_MODE']:
            logger.info("Verwende Demo-Daten für Snapshots")
            snapshot_data = demo_data.generate_snapshots_data(20)
        else:
            logger.info("Sammle echte Snapshot-Daten vom vCenter")
            # Hier die echten Daten vom vCenter abrufen
            snapshot_data = vsphere_client.get_snapshots() if vsphere_client else []
        
        return render_template('snapshots.html', 
                            snapshots=snapshot_data,
                            demo_mode=app.config['DEMO_MODE'])
    except Exception as e:
        logger.error(f"Fehler beim Abrufen der Snapshot-Daten: {e}")
        flash(f"Fehler beim Abrufen der Snapshot-Daten: {str(e)}", 'danger')
        return render_template('snapshots.html', 
                            snapshots=[],
                            demo_mode=app.config['DEMO_MODE'])

@app.route('/orphaned-vmdks')
@login_required
def orphaned_vmdks():
    """
    Zeigt eine Liste aller verwaisten VMDK-Dateien an.
    """
    try:
        if app.config['DEMO_MODE']:
            vmdk_data = demo_data.generate_orphaned_vmdks_data(15)
            logger.info(f"Generierte {len(vmdk_data)} verwaiste VMDKs für Demo-Modus")
        else:
            logger.info("Sammle echte VMDK-Daten vom vCenter")
            # Hier die echten Daten vom vCenter abrufen
            vmdk_data = vsphere_client.get_orphaned_vmdks() if vsphere_client else []
            logger.info(f"Abgerufene {len(vmdk_data) if vmdk_data else 0} verwaiste VMDKs vom vCenter")
        
        # Stelle sicher, dass vmdk_data nicht None ist
        if vmdk_data is None:
            vmdk_data = []
            logger.warning("Keine verwaisten VMDK-Daten gefunden, verwende leere Liste")
        
        return render_template('orphaned_vmdks.html', 
                            orphaned_vmdks=vmdk_data,
                            demo_mode=app.config['DEMO_MODE'])
    except Exception as e:
        logger.error(f"Fehler beim Abrufen der verwaisten VMDK-Daten: {e}")
        flash(f"Fehler beim Abrufen der verwaisten VMDK-Daten: {str(e)}", 'danger')
        return render_template('orphaned_vmdks.html', 
                            orphaned_vmdks=[],
                            demo_mode=app.config['DEMO_MODE'])

@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Anmeldeseite für die Verbindung zum vCenter.
    """
    form = LoginForm()
    
    if form.validate_on_submit():
        server = form.server.data
        username = form.username.data
        password = form.password.data
        ignore_ssl = form.ignore_ssl.data
        
        try:
            global vsphere_client
            vsphere_client = VSphereClient(server, username, password, ignore_ssl)
            vsphere_client.connect()
            
            # Anmeldedaten in der Session speichern
            session['is_authenticated'] = True
            session['vcenter_server'] = server
            session['username'] = username
            
            # Bei erfolgreicher Anmeldung mit echten Daten Demo-Modus deaktivieren
            app.config['DEMO_MODE'] = False
            os.environ['VSPHERE_REPORTER_DEMO'] = 'False'
            logger.info(f"Echte Verbindung zu {server} hergestellt - Demo-Modus deaktiviert")
            
            flash(f'Erfolgreich mit {server} verbunden.', 'success')
            return redirect(url_for('index'))
            
        except VSphereReporterError as e:
            flash(f'Verbindungsfehler: {str(e)}', 'danger')
            logger.error(f'Verbindungsfehler: {str(e)}')
            
        except Exception as e:
            flash(f'Unerwarteter Fehler: {str(e)}', 'danger')
            logger.error(f'Unerwarteter Fehler bei der Anmeldung: {str(e)}')
    
    # Demo-Modus für die Anzeige auf True setzen, damit der Button immer angezeigt wird
    return render_template('login.html', form=form, demo_mode=True)

@app.route('/demo-login')
def demo_login():
    """
    Aktiviert den Demo-Modus ohne vCenter-Verbindung.
    """
    # Demo-Modus aktivieren
    app.config['DEMO_MODE'] = True
    os.environ['VSPHERE_REPORTER_DEMO'] = 'True'
    
    # Session-Variablen setzen
    session['is_authenticated'] = True
    session['vcenter_server'] = 'Demo vCenter'
    session['username'] = 'demo-user@vsphere.local'
    
    # Stellen Sie sicher, dass vsphere_client auf None gesetzt ist, damit keine Fehler auftreten
    global vsphere_client
    vsphere_client = None
    
    logger.info("Demo-Modus aktiviert - vsphere_client auf None gesetzt")
    flash('Demo-Modus aktiviert. Sie verwenden simulierte Daten.', 'info')
    return redirect(url_for('index'))

@app.route('/disconnect')
def disconnect():
    """
    Trennt die Verbindung zum vCenter und meldet den Benutzer ab.
    """
    try:
        global vsphere_client
        if vsphere_client and not app.config['DEMO_MODE']:
            vsphere_client.disconnect()
            vsphere_client = None
    except Exception as e:
        logger.warning(f"Fehler beim Trennen der Verbindung: {e}")
    
    # Session zurücksetzen
    session.clear()
    
    flash('Sie wurden erfolgreich abgemeldet.', 'success')
    return redirect(url_for('login'))

@app.route('/export/<format>')
@login_required
def export(format):
    """
    Exportiert alle Berichte in verschiedenen Formaten.
    
    Args:
        format (str): Das gewünschte Format (html, pdf, docx)
    """
    if format not in ['html', 'pdf', 'docx']:
        flash(f'Ungültiges Format: {format}', 'danger')
        return redirect(url_for('index'))
    
    try:
        # Berichte sammeln
        if app.config['DEMO_MODE']:
            logger.info(f"Verwende Demo-Daten für {format}-Export")
            vmware_tools = demo_data.generate_vmware_tools_data(30)
            snapshots = demo_data.generate_snapshots_data(20)
            orphaned_vmdks = demo_data.generate_orphaned_vmdks_data(15)
        else:
            logger.info(f"Sammle echte Daten vom vCenter für {format}-Export")
            vmware_tools = vsphere_client.get_vmware_tools_status() if vsphere_client else []
            snapshots = vsphere_client.get_snapshots() if vsphere_client else []
            orphaned_vmdks = vsphere_client.get_orphaned_vmdks() if vsphere_client else []
        
        # Report-Generator initialisieren
        generator = ReportGenerator(
            output_dir=app.config['UPLOAD_FOLDER'],
            vcenter_server=session.get('vcenter_server', 'Demo vCenter'),
            username=session.get('username', 'demo-user@vsphere.local'),
            demo_mode=app.config['DEMO_MODE']
        )
        
        # Für alle Formate die gleichen Daten
        data = {'vmware_tools': vmware_tools, 'snapshots': snapshots, 'orphaned_vmdks': orphaned_vmdks}
        
        # Generiere Dateinamen mit Zeitstempel
        filename = f"vsphere_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{format}"
        
        # Basierend auf dem Format exportieren
        if format == 'html':
            report_file = generator.generate_html_report(filename, data)
            return send_file(report_file, as_attachment=True)
            
        elif format == 'pdf':
            report_file = generator.generate_pdf_report(filename, data)
            return send_file(report_file, as_attachment=True)
            
        elif format == 'docx':
            report_file = generator.generate_docx_report(filename, data)
            return send_file(report_file, as_attachment=True)
    
    except Exception as e:
        flash(f'Fehler beim Exportieren: {str(e)}', 'danger')
        logger.error(f"Fehler beim Exportieren im Format {format}: {str(e)}")
        return redirect(url_for('index'))

@app.route('/export-single/<report_type>/<format>')
@login_required
def export_single(report_type, format):
    """
    Exportiert einen einzelnen Bericht in verschiedenen Formaten.
    
    Args:
        report_type (str): Der Berichtstyp (vmware-tools, snapshots, orphaned-vmdks)
        format (str): Das gewünschte Format (html, pdf, docx)
    """
    if format not in ['html', 'pdf', 'docx']:
        flash(f'Ungültiges Format: {format}', 'danger')
        return redirect(url_for('index'))
    
    if report_type not in ['vmware-tools', 'snapshots', 'orphaned-vmdks']:
        flash(f'Ungültiger Berichtstyp: {report_type}', 'danger')
        return redirect(url_for('index'))
    
    try:
        # Daten sammeln
        data = {}
        
        if report_type == 'vmware-tools':
            if app.config['DEMO_MODE']:
                data['vmware_tools'] = demo_data.generate_vmware_tools_data(30)
            else:
                logger.info("Sammle echte VMware Tools-Daten vom vCenter für einzelnen Export")
                data['vmware_tools'] = vsphere_client.get_vmware_tools_status() if vsphere_client else []
        
        elif report_type == 'snapshots':
            if app.config['DEMO_MODE']:
                data['snapshots'] = demo_data.generate_snapshots_data(20)
            else:
                logger.info("Sammle echte Snapshot-Daten vom vCenter für einzelnen Export")
                data['snapshots'] = vsphere_client.get_snapshots() if vsphere_client else []
        
        elif report_type == 'orphaned-vmdks':
            if app.config['DEMO_MODE']:
                data['orphaned_vmdks'] = demo_data.generate_orphaned_vmdks_data(15)
            else:
                logger.info("Sammle echte verwaiste VMDK-Daten vom vCenter für einzelnen Export")
                data['orphaned_vmdks'] = vsphere_client.get_orphaned_vmdks() if vsphere_client else []
        
        # Report-Generator initialisieren
        generator = ReportGenerator(
            output_dir=app.config['UPLOAD_FOLDER'],
            vcenter_server=session.get('vcenter_server', 'Demo vCenter'),
            username=session.get('username', 'demo-user@vsphere.local'),
            demo_mode=app.config['DEMO_MODE']
        )
        
        # Basierend auf dem Format exportieren
        filename = f"{report_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{format}"
        
        if format == 'html':
            report_file = generator.generate_html_report(filename, data)
            return send_file(report_file, as_attachment=True)
        elif format == 'pdf':
            report_file = generator.generate_pdf_report(filename, data)
            return send_file(report_file, as_attachment=True)
        elif format == 'docx':
            report_file = generator.generate_docx_report(filename, data)
            return send_file(report_file, as_attachment=True)
        
    except Exception as e:
        flash(f'Fehler beim Exportieren: {str(e)}', 'danger')
        logger.error(f"Fehler beim Exportieren von {report_type} im Format {format}: {str(e)}")
        return redirect(url_for(report_type.replace('-', '_')))

# Fehlerseitenhandler
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html', demo_mode=app.config['DEMO_MODE']), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html', error_details=str(e), demo_mode=app.config['DEMO_MODE']), 500

# Nur zu Debugging-Zwecken
@app.route('/debug')
def debug():
    """
    Debug-Route, die nur verfügbar ist, wenn der Debug-Modus aktiviert ist.
    """
    if not app.debug:
        abort(404)
    
    # Debugging-Informationen sammeln
    debug_info = {
        'demo_mode': app.config['DEMO_MODE'],
        'session': dict(session),
        'vsphere_client': vsphere_client is not None,
        'python_version': sys.version,
        'environment': dict(os.environ)
    }
    
    return jsonify(debug_info)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)