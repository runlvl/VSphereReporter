"""
Core package initialization
"""
