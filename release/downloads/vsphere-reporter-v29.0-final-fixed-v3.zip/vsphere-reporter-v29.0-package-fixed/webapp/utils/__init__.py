"""
VMware vSphere Reporter v29.0 - Utility Modules
Copyright (c) 2025 Bechtle GmbH
"""