#!/bin/bash
echo "Starte VMware vSphere Reporter v29.0 (Web Edition)"
echo "Diese Version wird in v29.0 aktualisiert."
echo "Bitte führen Sie ./setup.sh aus, um alle erforderlichen Abhängigkeiten zu installieren."
echo "Dann führen Sie ./run.sh aus, um die Anwendung zu starten."
