"""VSphere Reporter Berichtsgenerator-Modul"""

from ..report_generator_original import ReportGenerator

# Exportiere die Klasse, damit sie über das Paket zugänglich ist
__all__ = ['ReportGenerator']
