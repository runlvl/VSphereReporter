"""VSphere Reporter Berichtsgenerator-Modul"""
