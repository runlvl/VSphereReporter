"""
VMware vSphere Reporter v29.0 - Web Edition
Utilities und Hilfsfunktionen
"""