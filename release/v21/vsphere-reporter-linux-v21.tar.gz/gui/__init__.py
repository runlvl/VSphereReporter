"""
GUI package initialization
"""
