"""
Core package initialization
"""