#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
VMware vSphere Reporter - VMDK-Dateierkennung
Speziell entwickelt, um ALLE VMDK-Dateien in der Umgebung anzuzeigen

NEUER ANSATZ:
Statt zu versuchen, nur "verwaiste" VMDK-Dateien zu identifizieren, 
zeigen wir jetzt ALLE VMDK-Dateien in der Umgebung an.
"""

import os
import re
import logging
import datetime
from pyVmomi import vim

# Configure logging
logger = logging.getLogger(__name__)

def collect_orphaned_vmdks(client):
    """
    NEUER ANSATZ IN V24.3-FINAL: Sammelt ALLE VMDKs ohne Filterung.
    
    Statt zu versuchen, "verwaiste" VMDKs zu identifizieren, gibt diese Funktion
    einfach alle gefundenen VMDK-Dateien zurück und zeigt diese in der Übersicht an.
    Dies bietet einen vollständigen Einblick in alle VMDKs der Umgebung.
    
    Args:
        client: Der VSphereClient
        
    Returns:
        list: Liste aller VMDK-Informationen
    """
    # Debug-Modus aktivieren für detaillierte Logs
    debug_mode = os.environ.get('VSPHERE_REPORTER_DEBUG', '0') == '1'
    if debug_mode:
        logger.warning("*** ALL VMDK COLLECTION - V24.3 (SHOWING ALL) ***")
    
    logger.info("Using ALL VMDK collection method v24.3 - Showing ALL VMDKs regardless of usage")
    
    # Eine Liste für alle VMDKs
    all_vmdks = []
    
    try:
        # Zugriff auf vSphere-Content
        content = client.service_instance.content
        
        # Alle Datacenters durchsuchen
        datacenters = [entity for entity in content.rootFolder.childEntity 
                      if isinstance(entity, vim.Datacenter)]
        
        if debug_mode:
            logger.warning(f"Found {len(datacenters)} datacenters to scan")
            
        for datacenter in datacenters:
            try:
                datastores = datacenter.datastore
                if debug_mode:
                    logger.warning(f"Datacenter {datacenter.name} has {len(datastores)} datastores")
                
                # Alle Datastores durchsuchen
                for datastore in datastores:
                    try:
                        if debug_mode:
                            logger.warning(f"Scanning datastore: {datastore.name}")
                        
                        # Datastore-Browser verwenden
                        browser = datastore.browser
                        
                        # Nur nach VMDK-Dateien suchen
                        search_spec = vim.HostDatastoreBrowserSearchSpec()
                        search_spec.matchPattern = ["*.vmdk"]
                        
                        # Suche durchführen
                        try:
                            task = browser.SearchDatastoreSubFolders_Task("[" + datastore.name + "]", search_spec)
                            client.wait_for_task(task)
                            search_results = task.info.result
                            
                            if debug_mode:
                                logger.warning(f"Found {len(search_results)} folders in datastore {datastore.name}")
                                
                        except Exception as e:
                            if debug_mode:
                                logger.error(f"Error searching datastore {datastore.name}: {str(e)}")
                            continue
                        
                        # Verarbeite die Suchergebnisse
                        for result in search_results:
                            folder_path = result.folderPath
                            
                            if debug_mode:
                                logger.warning(f"Checking folder: {folder_path} with {len(result.file)} files")
                                
                            for file_info in result.file:
                                try:
                                    # Nur VMDK-Dateien berücksichtigen
                                    if not file_info.path.lower().endswith('.vmdk'):
                                        continue
                                        
                                    # Sicherstellen, dass file_info.path nicht None ist
                                    if not hasattr(file_info, 'path') or file_info.path is None:
                                        if debug_mode:
                                            logger.warning(f"Found VMDK with None path in folder {folder_path}, skipping")
                                        continue
                                        
                                    # Vollständigen Pfad konstruieren
                                    full_path = folder_path + file_info.path
                                    
                                    # Sicherstellen, dass wir einen gültigen Pfad haben
                                    if not full_path or len(full_path) < 5:  # Minium ".vmdk"
                                        if debug_mode:
                                            logger.warning(f"Invalid VMDK path: {full_path}, skipping")
                                        continue
                                    
                                    # Nur flat-VMDKs überspringen, da diese immer zu einer anderen VMDK gehören
                                    if "-flat.vmdk" in full_path.lower():
                                        if debug_mode:
                                            logger.warning(f"Skipping -flat VMDK: {full_path}")
                                        continue
                                        
                                    # Andere bekannte Helper-VMDKs überspringen
                                    skip_patterns = ["-ctk.vmdk", "-delta.vmdk", "-rdm.vmdk", "-sesparse.vmdk"]
                                    should_skip = False
                                    for pattern in skip_patterns:
                                        if pattern in full_path.lower():
                                            if debug_mode:
                                                logger.warning(f"Skipping helper VMDK: {full_path} (matches {pattern})")
                                            should_skip = True
                                            break
                                            
                                    if should_skip:
                                        continue
                                    
                                    # Information über die VMDK sammeln
                                    # Fehlerbehandlung für fileSize, die manchmal None sein kann
                                    if file_info.fileSize is not None:
                                        size_mb = file_info.fileSize / (1024 * 1024)
                                    else:
                                        # Wenn fileSize None ist, verwenden wir einen Standardwert und protokollieren dies
                                        size_mb = 0.0
                                        if debug_mode:
                                            logger.warning(f"File size for {file_info.path} is None, using 0.0 as default")
                                    
                                    # Sicherstellen, dass modification_time nicht None ist
                                    modification_time = datetime.datetime.now()
                                    if hasattr(file_info, 'modification') and file_info.modification is not None:
                                        modification_time = file_info.modification
                                    else:
                                        if debug_mode:
                                            logger.warning(f"File {file_info.path} has no modification time, using current time")
                                    
                                    vmdk_info = {
                                        'path': full_path,
                                        'name': file_info.path,
                                        'datastore': datastore.name,
                                        'size_mb': size_mb,
                                        'modification_time': modification_time,
                                        'explanation': "ALLE VMDK-DATEIEN: Diese Auflistung zeigt alle VMDKs, unabhängig davon, ob sie verwendet werden."
                                    }
                                    
                                    # Zur Liste aller VMDKs hinzufügen
                                    all_vmdks.append(vmdk_info)
                                    
                                    if debug_mode:
                                        logger.warning(f"Found VMDK: {full_path}")
                                        
                                except Exception as e:
                                    if debug_mode:
                                        logger.error(f"Error processing file {file_info.path}: {str(e)}")
                                    continue
                    except Exception as e:
                        if debug_mode:
                            logger.error(f"Error processing datastore {datastore.name}: {str(e)}")
                        continue
            except Exception as e:
                if debug_mode:
                    logger.error(f"Error processing datacenter {datacenter.name}: {str(e)}")
                continue
        
        # FERTIG: Ergebnisse zurückgeben
        logger.info(f"ALL VMDK method found {len(all_vmdks)} total VMDKs")
        
        # Konfigurierbare Debug-Unterstützung
        debug_mode = os.environ.get('VSPHERE_REPORTER_DEBUG', '0') == '1'
        
        # Loggen, ob wir im Debug-Modus sind
        if debug_mode:
            logger.warning(f"Debug mode is ACTIVE, found {len(all_vmdks)} VMDKs")
            
        return all_vmdks
            
    except Exception as e:
        if debug_mode:
            import traceback
            logger.error(f"Error in ALL VMDK collection: {str(e)}")
            logger.error(f"Traceback: {traceback.format_exc()}")
        else:
            logger.debug(f"Error in ALL VMDK collection: {str(e)}")
        
        # Ein leeres Array zurückgeben, um weitere Verarbeitungsschritte zu ermöglichen
        logger.error("Error during VMDK collection, returning empty list")
        return []