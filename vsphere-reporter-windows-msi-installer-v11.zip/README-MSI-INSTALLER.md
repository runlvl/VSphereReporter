# VMware vSphere Reporter - MSI Installer

Dieses Paket enthält den Windows MSI Installer für den VMware vSphere Reporter.

## Installation

Um den MSI Installer zu erstellen:

1. Stellen Sie sicher, dass Python 3.8 oder höher installiert ist
2. Führen Sie `create_msi_installer.bat` aus
3. Der MSI-Installer wird im Verzeichnis `build/msi` erstellt

## Systemanforderungen

- Windows 10 oder höher
- 4 GB RAM
- 100 MB freier Festplattenspeicher

## Hinweise zur automatisierten Installation

Für eine automatisierte (Silent) Installation können Sie den MSI-Installer mit dem Parameter `/quiet` verwenden:

```
msiexec /i VSphereReporter-Setup.msi /quiet
```

## Update auf Version v9

### Fehlerbehebungen
- Verbesserte Fehlerbehandlung in allen Datenerfassungsmethoden
- Implementierte vollständige Fehlerunterdrückung mit 'suppress_stdout_stderr()' für alle PyVmomi-Operationen
- Behoben: RegEx-Fehlerbehandlung für Datastore-Pfade

### Funktionen
- Verbesserte Log-Level-Auswahl im Linux-Benutzerinterface
- Umleitung aller PyVmomi-Fehlermeldungen zum Logger statt zum Befehlsfenster
- Optimiertes Installationsskript für OpenSuse Tumbleweed
