# VMware vSphere Reporter - MSI Installer

Dieses Paket enthält den Windows MSI Installer für den VMware vSphere Reporter.

## Installation

Um den MSI Installer zu erstellen:

1. Stellen Sie sicher, dass Python 3.8 oder höher installiert ist
2. Führen Sie `create_msi_installer.bat` aus
3. Der MSI-Installer wird im Verzeichnis `build/msi` erstellt

## Systemanforderungen

- Windows 10 oder höher
- 4 GB RAM
- 100 MB freier Festplattenspeicher

## Hinweise zur automatisierten Installation

Für eine automatisierte (Silent) Installation können Sie den MSI-Installer mit dem Parameter `/quiet` verwenden:

```
msiexec /i VSphereReporter-Setup.msi /quiet
```

## Update auf Version v10

### Fehlerbehebungen
- Ersetzung des vertikalen Inhaltsverzeichnisses durch ein horizontales Navigationsmenü
- Korrektur der Sprungmarken mit JavaScript für reibungsloses Scrollen
- Sicherstellen, dass das Bechtle-Logo immer angezeigt wird
- Verbesserte Fehlerunterdrückung in allen Datenerfassungsmethoden

### Funktionen
- Neues horizontales Menü als feste Navigation, die beim Scrollen sichtbar bleibt
- Interaktive Hervorhebung des aktuellen Abschnitts in der Navigation
- Größeres Bechtle-Logo in den HTML-Berichten
- Verbesserte Log-Level-Auswahl
