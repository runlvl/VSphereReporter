"""
GUI package initialization
"""