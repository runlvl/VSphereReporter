"""
Utilities package initialization
"""
