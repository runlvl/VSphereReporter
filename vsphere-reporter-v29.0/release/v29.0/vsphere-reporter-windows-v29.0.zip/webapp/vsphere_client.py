#!/usr/bin/env python3
"""
VSphere Client Module
Contains classes for connecting to and interacting with vSphere environments
"""

import ssl
import atexit
import logging
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim, vmodl

# Configure logger
logger = logging.getLogger(__name__)

class VSphereClient:
    """Client for connecting to and interacting with vSphere environments"""
    
    def __init__(self, host, user, password, ignore_ssl=False):
        """Initialize client with connection parameters"""
        self.host = host
        self.user = user
        self.password = password
        self.ignore_ssl = ignore_ssl
        self.service_instance = None
        self.content = None
        self.connected = False
    
    def connect(self):
        """Connect to vCenter Server"""
        logger.info(f"Connecting to vCenter Server: {self.host}")
        
        # Create SSL context if ignoring SSL verification
        if self.ignore_ssl:
            ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
            ssl_context.verify_mode = ssl.CERT_NONE
        else:
            ssl_context = None
        
        try:
            self.service_instance = SmartConnect(
                host=self.host,
                user=self.user,
                pwd=self.password,
                sslContext=ssl_context
            )
            
            # Register disconnect function for cleanup
            atexit.register(Disconnect, self.service_instance)
            
            # Get vCenter content
            self.content = self.service_instance.RetrieveContent()
            self.connected = True
            
            logger.info(f"Successfully connected to vCenter Server: {self.host}")
            
        except vim.fault.InvalidLogin as e:
            logger.error(f"Authentication failed: {str(e)}")
            raise Exception(f"Invalid username or password for vCenter Server: {self.host}")
        
        except Exception as e:
            logger.error(f"Failed to connect to vCenter Server: {str(e)}")
            raise Exception(f"Connection to vCenter Server failed: {str(e)}")
        
        return self.content
    
    def disconnect(self):
        """Disconnect from vCenter Server"""
        if self.service_instance:
            try:
                Disconnect(self.service_instance)
                logger.info(f"Disconnected from vCenter Server: {self.host}")
            except Exception as e:
                logger.error(f"Error disconnecting from vCenter Server: {str(e)}")
            
            self.service_instance = None
            self.content = None
            self.connected = False
    
    def is_connected(self):
        """Check if connected to vCenter Server"""
        return self.connected and self.service_instance is not None
    
    def get_all_vms(self):
        """Get all virtual machines in the environment"""
        if not self.is_connected():
            raise Exception("Not connected to vCenter Server")
        
        view_manager = self.content.viewManager
        container = self.content.rootFolder
        
        vm_view = view_manager.CreateContainerView(container, [vim.VirtualMachine], True)
        vms = list(vm_view.view)
        vm_view.Destroy()
        
        return vms
    
    def get_all_hosts(self):
        """Get all ESXi hosts in the environment"""
        if not self.is_connected():
            raise Exception("Not connected to vCenter Server")
        
        view_manager = self.content.viewManager
        container = self.content.rootFolder
        
        host_view = view_manager.CreateContainerView(container, [vim.HostSystem], True)
        hosts = list(host_view.view)
        host_view.Destroy()
        
        return hosts
    
    def get_all_datastores(self):
        """Get all datastores in the environment"""
        if not self.is_connected():
            raise Exception("Not connected to vCenter Server")
        
        view_manager = self.content.viewManager
        container = self.content.rootFolder
        
        datastore_view = view_manager.CreateContainerView(container, [vim.Datastore], True)
        datastores = list(datastore_view.view)
        datastore_view.Destroy()
        
        return datastores
    
    def get_all_clusters(self):
        """Get all clusters in the environment"""
        if not self.is_connected():
            raise Exception("Not connected to vCenter Server")
        
        view_manager = self.content.viewManager
        container = self.content.rootFolder
        
        cluster_view = view_manager.CreateContainerView(container, [vim.ClusterComputeResource], True)
        clusters = list(cluster_view.view)
        cluster_view.Destroy()
        
        return clusters
    
    def get_all_resource_pools(self):
        """Get all resource pools in the environment"""
        if not self.is_connected():
            raise Exception("Not connected to vCenter Server")
        
        view_manager = self.content.viewManager
        container = self.content.rootFolder
        
        rp_view = view_manager.CreateContainerView(container, [vim.ResourcePool], True)
        resource_pools = list(rp_view.view)
        rp_view.Destroy()
        
        return resource_pools
    
    def get_all_networks(self):
        """Get all networks in the environment"""
        if not self.is_connected():
            raise Exception("Not connected to vCenter Server")
        
        view_manager = self.content.viewManager
        container = self.content.rootFolder
        
        net_view = view_manager.CreateContainerView(container, [vim.Network], True)
        networks = list(net_view.view)
        net_view.Destroy()
        
        return networks
    
    def get_all_datacenters(self):
        """Get all datacenters in the environment"""
        if not self.is_connected():
            raise Exception("Not connected to vCenter Server")
        
        view_manager = self.content.viewManager
        container = self.content.rootFolder
        
        dc_view = view_manager.CreateContainerView(container, [vim.Datacenter], True)
        datacenters = list(dc_view.view)
        dc_view.Destroy()
        
        return datacenters
    
    def wait_for_task(self, task):
        """Wait for a vCenter task to complete"""
        task_done = False
        while not task_done:
            if task.info.state == vim.TaskInfo.State.success:
                return task.info.result
            
            if task.info.state == vim.TaskInfo.State.error:
                raise task.info.error
            
            if task.info.state == vim.TaskInfo.State.running:
                continue
            
            task_done = True