"""
Utility modules for the VMware vSphere Reporter Web Edition
"""