#!/usr/bin/env python3
"""
Error Handler for VMware vSphere Reporter Web Edition
Provides centralized error handling and user-friendly error messages
"""

import logging
import traceback
from datetime import datetime
from pyVmomi import vim, vmodl

# Configure logger
logger = logging.getLogger(__name__)

class ErrorHandler:
    """Centralized error handler for vSphere Reporter"""
    
    def __init__(self, logger=None):
        """
        Initialize the error handler
        
        Args:
            logger: Logger instance to use (optional)
        """
        self.logger = logger or logging.getLogger(__name__)
    
    def handle_error(self, exception, default_message="An error occurred"):
        """
        Handle an exception and return a user-friendly error message
        
        Args:
            exception: The exception to handle
            default_message: Default message to use if exception type is not recognized
            
        Returns:
            str: User-friendly error message
        """
        # Log the full exception with traceback
        self.logger.error(f"Error: {str(exception)}")
        self.logger.debug(f"Traceback: {traceback.format_exc()}")
        
        # Handle known vSphere exceptions
        if isinstance(exception, vim.fault.InvalidLogin):
            return "Invalid username or password. Please check your credentials."
        
        elif isinstance(exception, vim.fault.HostConnectFault):
            return "Failed to connect to ESXi host. Please check network connectivity and credentials."
        
        elif isinstance(exception, vim.fault.NotAuthenticated):
            return "Authentication timed out or not authenticated. Please reconnect to vCenter."
        
        elif isinstance(exception, vim.fault.NoPermission):
            return "Insufficient permissions to perform the requested operation."
        
        elif isinstance(exception, vmodl.fault.NotSupported):
            return "This operation is not supported on the target server."
        
        elif isinstance(exception, vmodl.fault.InvalidArgument):
            return f"Invalid argument: {str(exception)}"
        
        elif isinstance(exception, vmodl.fault.ManagedObjectNotFound):
            return "The requested object was not found in vCenter."
        
        elif isinstance(exception, vim.fault.RestrictedVersion):
            return "This operation is not supported in your vSphere version."
        
        elif isinstance(exception, ConnectionError):
            return "Connection error. Please check network connectivity to vCenter."
        
        elif isinstance(exception, TimeoutError):
            return "Connection timed out. vCenter server may be overloaded or unreachable."
        
        # Handle file system exceptions
        elif isinstance(exception, FileNotFoundError):
            return f"File not found: {str(exception)}"
        
        elif isinstance(exception, PermissionError):
            return f"Permission denied: {str(exception)}"
        
        # For any other exception, log details and return generic message
        else:
            error_id = datetime.now().strftime("%Y%m%d%H%M%S")
            self.logger.error(f"Unhandled exception (ID: {error_id}): {str(exception)}")
            self.logger.debug(f"Exception type: {type(exception).__name__}")
            
            # Return a user-friendly message with error ID for reference
            return f"{default_message} (Error ID: {error_id}). Please check the logs for details."
    
    def log_warning(self, message):
        """
        Log a warning message
        
        Args:
            message: Warning message to log
        """
        self.logger.warning(message)