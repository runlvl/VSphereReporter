#!/usr/bin/env python3
"""
Logger module for the VMware vSphere Reporter Web Edition
"""

import os
import logging
from datetime import datetime

def setup_logger(log_dir=None):
    """
    Set up and configure the application logger
    
    Args:
        log_dir: Directory to store log files (default: logs directory in script location)
        
    Returns:
        Configured logger instance
    """
    # Create logger
    logger = logging.getLogger('vsphere_reporter')
    logger.setLevel(logging.DEBUG)
    
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Create file handler if log directory is provided
    if log_dir:
        # Create log directory if it doesn't exist
        os.makedirs(log_dir, exist_ok=True)
        
        # Generate log filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = os.path.join(log_dir, f'vsphere_reporter_{timestamp}.log')
        
        # Create file handler
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        logger.info(f'Log file created at: {log_file}')
    
    # Enable debug logging if environment variable is set
    if os.environ.get('VSPHERE_REPORTER_DEBUG') == '1':
        console_handler.setLevel(logging.DEBUG)
        logger.debug('Debug logging enabled')
    
    return logger