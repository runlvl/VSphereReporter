#!/usr/bin/env python3
"""
VMware vSphere Reporter - Web Edition v29.0
A comprehensive browser-based reporting tool for VMware vSphere environments

Copyright (c) 2025 Bechtle GmbH
"""

import os
import time
import logging
import uuid
import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, jsonify, session, send_file, flash
from werkzeug.security import generate_password_hash, check_password_hash

# Import core modules
from webapp.vsphere_client import VSphereClient
from webapp.data_collector import DataCollector
from webapp.report_generator import ReportGenerator
from webapp.direct_vmdk_collector import DirectVMDKCollector
from webapp.topology_generator import TopologyGenerator
from webapp.utils.logger import setup_logger
from webapp.utils.error_handler import ErrorHandler

# Initialize Flask application
app = Flask(__name__, 
            static_folder='static',
            template_folder='templates')

# Set a secret key for session management
app.secret_key = os.environ.get('VSPHERE_REPORTER_SECRET_KEY', str(uuid.uuid4()))

# Session timeout (12 hours)
app.config['PERMANENT_SESSION_LIFETIME'] = 43200

# Setup logging
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)
logger = setup_logger(log_dir)

# Initialize error handler
error_handler = ErrorHandler(logger)

# Global variables
session_clients = {}
session_collectors = {}
report_options = {
    'vmware_tools': True,
    'snapshots': True,
    'orphaned_vmdks': True,
    'vm_hardware': True,
    'datastores': True,
    'clusters': True,
    'esxi_hosts': True,
    'resource_pools': True,
    'networks': True,
    'topology': True,
}


@app.route('/')
def index():
    """Render the main application page"""
    is_connected = 'vsphere_client' in session and session['vsphere_client']
    connection_info = {}
    if is_connected:
        connection_info = {
            'server': session.get('vsphere_server', ''),
            'username': session.get('vsphere_username', ''),
        }
    return render_template('index.html', 
                          is_connected=is_connected,
                          connection_info=connection_info,
                          report_options=report_options)


@app.route('/connect', methods=['GET', 'POST'])
def connect():
    """Handle vCenter connection"""
    if request.method == 'POST':
        server = request.form.get('server')
        username = request.form.get('username')
        password = request.form.get('password')
        ignore_ssl = 'ignore_ssl' in request.form
        
        logger.info(f"Connecting to vCenter server: {server}")
        
        try:
            # Create vSphere client
            client = VSphereClient(server, username, password, ignore_ssl)
            client.connect()
            
            # Store connection details in session
            session_id = str(uuid.uuid4())
            session['vsphere_client'] = session_id
            session['vsphere_server'] = server
            session['vsphere_username'] = username
            session_clients[session_id] = client
            
            # Create data collector
            collector = DataCollector(client)
            session_collectors[session_id] = collector
            
            flash('Successfully connected to vCenter server', 'success')
            return redirect(url_for('index'))
        
        except Exception as e:
            error_message = error_handler.handle_error(e, "Failed to connect to vCenter server")
            flash(error_message, 'error')
            logger.error(f"Connection failed: {error_message}")
            return render_template('connect.html', error=error_message)
    
    return render_template('connect.html')


@app.route('/disconnect')
def disconnect():
    """Disconnect from vCenter"""
    if 'vsphere_client' in session:
        session_id = session['vsphere_client']
        if session_id in session_clients:
            try:
                client = session_clients[session_id]
                client.disconnect()
                del session_clients[session_id]
            except Exception as e:
                logger.error(f"Error disconnecting: {str(e)}")
            
        if session_id in session_collectors:
            del session_collectors[session_id]
    
    # Clear session data
    session.pop('vsphere_client', None)
    session.pop('vsphere_server', None)
    session.pop('vsphere_username', None)
    
    flash('Disconnected from vCenter server', 'info')
    return redirect(url_for('index'))


@app.route('/options', methods=['GET', 'POST'])
def options():
    """Configure report options"""
    global report_options
    
    if request.method == 'POST':
        # Update report options based on form input
        report_options = {
            'vmware_tools': 'vmware_tools' in request.form,
            'snapshots': 'snapshots' in request.form,
            'orphaned_vmdks': 'orphaned_vmdks' in request.form,
            'vm_hardware': 'vm_hardware' in request.form,
            'datastores': 'datastores' in request.form,
            'clusters': 'clusters' in request.form,
            'esxi_hosts': 'esxi_hosts' in request.form,
            'resource_pools': 'resource_pools' in request.form,
            'networks': 'networks' in request.form,
            'topology': 'topology' in request.form,
        }
        
        flash('Report options saved successfully', 'success')
        return redirect(url_for('index'))
    
    return render_template('options.html', report_options=report_options)


@app.route('/generate_report', methods=['POST'])
def generate_report():
    """Generate vSphere report based on selected options"""
    if 'vsphere_client' not in session:
        flash('Not connected to vCenter server', 'error')
        return redirect(url_for('index'))
    
    session_id = session['vsphere_client']
    if session_id not in session_clients or session_id not in session_collectors:
        flash('Session expired. Please reconnect to vCenter', 'error')
        return redirect(url_for('index'))
    
    client = session_clients[session_id]
    collector = session_collectors[session_id]
    
    # Get export format
    export_format = request.form.get('export_format', 'html')
    
    # Use report options from global variable
    options = report_options
    
    # Create timestamp for report filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename_base = f"vsphere_report_{timestamp}"
    
    try:
        # Setup VMDK collector if needed
        if options['orphaned_vmdks']:
            vmdk_collector = DirectVMDKCollector(client)
        
        # Setup topology generator if needed
        if options['topology']:
            topology_generator = TopologyGenerator(client)
        
        # Create report generator with error handling
        report_generator = ReportGenerator(collector)
        
        # Generate report based on selected format
        if export_format == 'html':
            output_file = os.path.join(app.root_path, 'reports', f"{filename_base}.html")
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            report_generator.generate_html_report(
                output_file, 
                include_vmware_tools=options['vmware_tools'],
                include_snapshots=options['snapshots'],
                include_orphaned_vmdks=options['orphaned_vmdks'],
                include_vm_hardware=options['vm_hardware'],
                include_datastores=options['datastores'],
                include_clusters=options['clusters'],
                include_hosts=options['esxi_hosts'],
                include_resource_pools=options['resource_pools'],
                include_networks=options['networks'],
                include_topology=options['topology']
            )
            
            # Store report path in session for download
            session['report_file'] = output_file
            session['report_type'] = 'html'
            
            flash('Report generated successfully', 'success')
            return redirect(url_for('report_status'))
            
        elif export_format == 'pdf':
            output_file = os.path.join(app.root_path, 'reports', f"{filename_base}.pdf")
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            report_generator.generate_pdf_report(
                output_file,
                include_vmware_tools=options['vmware_tools'],
                include_snapshots=options['snapshots'],
                include_orphaned_vmdks=options['orphaned_vmdks'],
                include_vm_hardware=options['vm_hardware'],
                include_datastores=options['datastores'],
                include_clusters=options['clusters'],
                include_hosts=options['esxi_hosts'],
                include_resource_pools=options['resource_pools'],
                include_networks=options['networks'],
                include_topology=options['topology']
            )
            
            # Store report path in session for download
            session['report_file'] = output_file
            session['report_type'] = 'pdf'
            
            flash('Report generated successfully', 'success')
            return redirect(url_for('report_status'))
            
        elif export_format == 'docx':
            output_file = os.path.join(app.root_path, 'reports', f"{filename_base}.docx")
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            report_generator.generate_docx_report(
                output_file,
                include_vmware_tools=options['vmware_tools'],
                include_snapshots=options['snapshots'],
                include_orphaned_vmdks=options['orphaned_vmdks'],
                include_vm_hardware=options['vm_hardware'],
                include_datastores=options['datastores'],
                include_clusters=options['clusters'],
                include_hosts=options['esxi_hosts'],
                include_resource_pools=options['resource_pools'],
                include_networks=options['networks'],
                include_topology=options['topology']
            )
            
            # Store report path in session for download
            session['report_file'] = output_file
            session['report_type'] = 'docx'
            
            flash('Report generated successfully', 'success')
            return redirect(url_for('report_status'))
        
        else:
            flash('Invalid export format selected', 'error')
            return redirect(url_for('index'))
            
    except Exception as e:
        error_message = error_handler.handle_error(e, "Failed to generate report")
        flash(error_message, 'error')
        logger.error(f"Report generation failed: {error_message}")
        return redirect(url_for('index'))


@app.route('/report_status')
def report_status():
    """Show report generation status and download link"""
    if 'report_file' not in session:
        flash('No report has been generated', 'error')
        return redirect(url_for('index'))
    
    report_file = session['report_file']
    report_type = session.get('report_type', 'html')
    
    if not os.path.exists(report_file):
        flash('Report file not found', 'error')
        return redirect(url_for('index'))
    
    # Get file size
    file_size = os.path.getsize(report_file) / (1024 * 1024)  # Convert to MB
    
    return render_template('report_status.html', 
                          file_size="{:.2f}".format(file_size),
                          report_type=report_type)


@app.route('/download_report')
def download_report():
    """Download generated report"""
    if 'report_file' not in session:
        flash('No report available for download', 'error')
        return redirect(url_for('index'))
    
    report_file = session['report_file']
    
    if not os.path.exists(report_file):
        flash('Report file not found', 'error')
        return redirect(url_for('index'))
    
    report_type = session.get('report_type', 'html')
    mimetype = {
        'html': 'text/html',
        'pdf': 'application/pdf',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    }.get(report_type, 'application/octet-stream')
    
    return send_file(report_file, 
                     as_attachment=True, 
                     download_name=os.path.basename(report_file),
                     mimetype=mimetype)


@app.route('/api/healthcheck')
def healthcheck():
    """API endpoint for health checks"""
    return jsonify({'status': 'ok', 'version': '29.0'})


@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500


if __name__ == '__main__':
    # Create reports directory if it doesn't exist
    reports_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    
    # Get port from environment or use default
    port = int(os.environ.get('PORT', 5000))
    
    # Enable debug mode if specified in environment
    debug_mode = os.environ.get('VSPHERE_REPORTER_DEBUG', '0').lower() in ('1', 'true', 'yes')
    
    # Start Flask application
    app.run(host='0.0.0.0', port=port, debug=debug_mode)