"""
VMware vSphere Reporter Web Edition
Core modules package
"""

__version__ = '29.0'
__author__ = 'Bechtle GmbH'